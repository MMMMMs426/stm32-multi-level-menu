#include "menu.h"
#include "oled.h"
#include "key.h"
#include "stm32f10x.h"
#include "stdio.h"
#include "bmp.h"
//2023/04/08                ҹ·����
// stm32mini ������   key0--->next          wake_up --->enter 
 
void (*current_operation_index)();       //ִ�е�ǰ��������
uint8_t func_index = 0;
int key_state;                           //���յ�ǰ�İ���״̬
Menu_table table[9] =
{
        {0, 0, 1, (*fun0)},     //һ������
        {1, 2, 5, (*fun1)},     //�����˵�  
        {2, 3, 6, (*fun2)},     //�����˵�  
        {3, 4, 7, (*fun3)},     //�����˵�  
        {4, 1, 0, (*fun4)},     //�����˵� Back

        {5, 6, 4, (*fun5)},      //�����˵� Back
        {6, 7, 0, (*fun6)},      //�����˵�  
        {7, 8, 0, (*fun7)},      //�����˵�  
        {8, 5, 0, (*fun8)},      //�����˵�  
};
void Menu_key_set(void)
{
    key_state = KEY_Scan(0);
	  //printf("%d\r\n",key_state);
    if (key_state == 1)
    {
			  OLED_Clear();
        func_index = table[func_index].next;
    }
    if(key_state == 3)
		{
			  OLED_Clear();
				func_index = table[func_index].enter;
		}			
		printf("func_index:%d\r\n",func_index);
    current_operation_index = table[func_index].current_operation;
    (*current_operation_index)(); //ִ�е�ǰ��������
}
void meun1_func(void)
{
    OLED_ShowString(0, 0, "   1.Back    ", 16);
    OLED_ShowString(0, 2, "   2.b", 16);
    OLED_ShowString(0, 4, "   3.c", 16);
    OLED_ShowString(0, 6, "   4.d", 16);
}

void meun2_func(void)
{
    OLED_ShowString(0, 0, "   1.Back    ", 16);
    OLED_ShowString(0, 2, "   2.e", 16);
    OLED_ShowString(0, 4, "   3.f", 16);
    OLED_ShowString(0, 6, "   4.g", 16);
}

//void meun3_func(void)
//{
//    OLED_ShowString(0, 0, "   1.Back    ", 16);
//    OLED_ShowString(0, 17, "   2.h", 16);
//    OLED_ShowString(0, 33, "   3.i", 16);
//    OLED_ShowString(0, 49, "   4.j", 16);
//}
//��ҳ��
void fun0(void)
{
    //OLED_ShowString(57, 1, "", 16);
    //OLED_ShowString(57,4, ":  :", 16);
    //OLED_ShowString(25, 65, "num =", 16);
    //OLED_ShowNum(65, 66, 11, 4, 16);
    //OLED_ShowNum(73, 40, 23, 2, 16);
    //OLED_ShowNum(37, 40, 34, 2, 16);
	  //OLED_ShowNum(0, 40, 45, 2, 16);
	  OLED_DrawBMP(40,2,88,8,BMP2);
}
void fun1(void)
{
    meun1_func();
    OLED_ShowString(0, 0, "-> ", 16);
}

void fun2(void)
{
    meun1_func();
    OLED_ShowString(0, 2, "-> ", 16);
}

void fun3(void)
{
    meun1_func();
    OLED_ShowString(0, 4, "-> ", 16);
}

void fun4(void)
{
    meun1_func();
    OLED_ShowString(0, 6, "-> ", 16);
}
void fun5(void)
{
    meun2_func();
    OLED_ShowString(0, 0, "-> ", 16);
}

void fun6(void)
{
    meun2_func();
    OLED_ShowString(0, 2, "-> ", 16);
}

void fun7(void)
{
    meun2_func();
    OLED_ShowString(0, 4, "-> ", 16);
}

void fun8(void)
{
    meun2_func();
    OLED_ShowString(0, 6, "-> ", 16);
}
